# Data and analytics — F&B Inventory Management SaaS

INF2006 Team Project. This covers the **data/AI portion only**. The web
application, cloud infrastructure and report live elsewhere in the submission.

Drop `data/`, `analytics/` and the `evidence/` files into the project ZIP at
their matching paths.

---

## Quickstart

```bash
pip install -r analytics/requirements.txt

python3 analytics/build_ledger.py      # rebuilds data/ from data/raw/Coffe_sales.csv
python3 analytics/forecast.py          # weekly forecast + walk-forward backtest
python3 analytics/evaluate_policy.py   # stockout/waste policy simulation
```

Fixed seed (2006), no network calls, output byte-identical across runs.
Checksums print at the end of `build_ledger.py`. The scripts resolve paths from
the repository root, so they run from any working directory.

---

## What the data is

Source is a Kaggle coffee-shop point-of-sale export: 3,547 real transactions,
1 March 2024 to 23 March 2025. It records **sales only** — no deliveries, no
wastage, no opening stock, no stock locations.

Sales are expanded through a recipe into the ingredients they consume, because
a cafe stocks beans, milk and cups, not "lattes". Deliveries, spoilage and
stocktakes are then simulated around the real sales so the ledger balances and
never goes negative.

Every ledger row carries a `source` column (`derived` from a real sale, or
`synthetic`), and every SELL row traces back to its originating transaction via
`sale_id`. Do not delete those columns: they are what makes the provenance
claim checkable.

| File | Rows | Contents |
|---|---|---|
| `data/ingredients.csv` | 8 | Stock items, shelf lives, pack sizes, locations |
| `data/recipes.csv` | 36 | Bill of materials, drink → ingredient quantities |
| `data/stock_movements.csv` | 17,049 | The append-only ledger |
| `data/daily_demand.csv` | 3,104 | Modelling table, day × ingredient |
| `data/weekly_demand.csv` | 448 | Modelling table, week × ingredient |
| `data/DATA_DICTIONARY.md` | — | Every field, its provenance, and limitations |

**Current stock is never stored.** Because `quantity` is signed, it is always:

```sql
SELECT ingredient_id, SUM(quantity) FROM stock_movements GROUP BY ingredient_id;
```

---

## What the analytics does

Weekly demand forecast per ingredient, using a moving average over recent
complete weeks, converted into a reorder quantity in whole supplier packs.
Everything is forecast weekly because four ingredients are too sparse for a
reliable daily forecast.

Evaluated twice, because forecast accuracy and stockout prevention are
different questions:

1. **Accuracy** (`forecast.py`) — walk-forward backtest, 47 scored weeks per
   ingredient, MASE against a naive baseline.
2. **Business outcome** (`evaluate_policy.py`) — replays the full year under
   each ordering policy and counts stockouts and waste.

### Headline results

- The forecast raises service level from **91.7%** (no forecast, fixed reorder
  level) to about **95.5%** — roughly **100 fewer stockout days per year**.
- **Which forecast method is used barely matters**: about 0.5 percentage
  points between naive, MA-2 and MA-4.
- The largest single lever found was **ordering milk twice weekly instead of
  weekly**, worth nearly nine points of service level on that ingredient.
- MA-2 wins on accuracy (MASE 0.963) but is *worse than naive on milk*
  (1.072), the ingredient that matters most.
- An 8-week linear trend was tested on the expectation it would capture the
  year-long doubling in demand. It was worse than both. Reported as a negative
  result.

Full write-up with method, results and limitations: `analytics/evaluation.md`.

---

## Files by purpose

**Scripts** — `analytics/build_ledger.py`, `forecast.py`, `evaluate_policy.py`,
`requirements.txt`

**Results** — `analytics/evaluation.md` (the write-up),
`forecast_backtest.csv` (2,632 individual predictions),
`method_comparison.csv`, `method_comparison_by_ingredient.csv`,
`policy_comparison.csv`, `reorder_recommendations.csv`

**Charts** — `analytics/forecast_plot.png` (actual vs forecast),
`policy_tradeoff.png` (what actually prevents stockouts)

**Evidence** — `evidence/test-data-ai.md` is the required **Test 3**
(data/AI validation), in objective/expected/actual/diagnosis format with a
hand-checkable case a marker can verify on paper.
`evidence/data-validation-report.txt` shows the ledger integrity checks.

---

## Manifest entries for this portion

```yaml
evidence:
  data_ai_test: "evidence/test-data-ai.md"

data_ai:
  dataset: "data/DATA_DICTIONARY.md"
  method: >-
    Weekly demand forecast per ingredient using a moving average over recent
    complete weeks, converted into a reorder quantity in whole supplier packs.
  evaluation: >-
    Walk-forward backtest (MASE 0.963 for MA-2 against a naive baseline) plus a
    full-year policy simulation showing service level rising from 91.7% to
    about 95.5%, roughly 100 fewer stockout days per year.
  reproducible_command: >-
    pip install -r analytics/requirements.txt &&
    python3 analytics/build_ledger.py &&
    python3 analytics/forecast.py &&
    python3 analytics/evaluate_policy.py
```

---

## Limitations

Stated in full in `data/DATA_DICTIONARY.md` and `analytics/evaluation.md`.
Short version:

- **Recipe quantities are invented.** Sales are real; "a latte uses 220 ml of
  milk" is an estimate. All ingredient-level demand inherits that assumption.
- **Shelf lives, pack sizes, costs and storage locations are invented.**
- **Deliveries and wastage are simulated**, so the forecast is partly being
  scored on predicting a process whose rules are known.
- **Only milk ever spoils** — it is the sole short-shelf-life item.
- **One year, one location.** No second year to separate seasonality from
  one-off events.
- **Three ingredients have intermittent demand** (8 oz cups, drinking
  chocolate, cocoa powder); weekly aggregation makes them usable but intervals
  stay wide.

---

## Before you submit

- [ ] **Confirm the Kaggle dataset licence.** `data/raw/Coffe_sales.csv` is
      included so the pipeline reproduces end to end. If the licence is not
      permissive, remove it and reference the source by URL in
      `DATA_DICTIONARY.md` instead.
- [ ] **Check the schema against the web app.** One drink sale writes four or
      five ledger rows via the recipe table. If the app team built a
      drink-level schema, this needs reconciling.
- [ ] **Decide the milk method** and say which you chose: MA-2 everywhere with
      milk noted as a limitation (current behaviour), or naive for milk. Either
      is defensible; leaving it unstated is not.
- [ ] Add your name and date to the header of `evidence/test-data-ai.md`.
