# Team contributions

One row per member. Be specific: name the files, features, tests and evidence each person owns,
so a marker can trace them.

| Member (name, student ID) | Role                                          | Artefacts / commits                                                                                   | Tests and evidence owned                                                  | Reflection (2–3 sentences) |
| ------------------------- | --------------------------------------------- | ----------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- | -------------------------- |
| TO FILL                   | TO FILL (e.g. cloud and infrastructure lead)  | TO FILL (e.g. `src/infra/network.yaml`, `database.yaml`, `app.yaml`; AWS deployment)                  | TO FILL (e.g. `evidence/test-resilience.md`, `evidence/deployment.md`)    | TO FILL                    |
| TO FILL                   | TO FILL (e.g. data and ML lead)               | TO FILL (e.g. `analytics/build_ledger.py`, `forecast.py`, `evaluate_policy.py`, `demand_model.ipynb`) | TO FILL (e.g. `evidence/test-data-ai.md`)                                 | TO FILL                    |
| TO FILL                   | TO FILL (e.g. application and security lead)  | TO FILL (e.g. `src/backend/`, `src/frontend/`, Cognito set-up)                                        | TO FILL (e.g. `evidence/test-functional.md`, `evidence/test-security.md`) | TO FILL                    |
| TO FILL                   | TO FILL (e.g. operations, testing and report) | TO FILL (e.g. monitoring, `report.pdf`, submission package)                                           | TO FILL (e.g. `evidence/monitoring.md`, `evidence/test-runs/SUMMARY.md`)  | TO FILL                    |

## How work was shared

TO FILL — how you split the work, how you reviewed each other's parts (e.g. a teammate who
didn't build a piece followed its instructions from scratch), and how you used the AI assistant
(see `AI_USE_DECLARATION.md`).

## Agreement

All members have read this file and agree it's accurate: TO FILL (names and date).
